package oose_7_1;

public class DoubleList {
	DoubleNode head;
	
	DoubleList() {
		
	}
	
	DoubleList(DoubleNode h) {
		this.head = h;
	}
	
	void add(double d) {
		if (this.head == null) {
			head = new DoubleNode(d);
		} else {
			DoubleNode cursor = head;
			while (cursor.getNext() != null) {
				cursor = cursor.getNext();
			}
			DoubleNode newNode = new DoubleNode(d);
			cursor.setNext(newNode);
		}
	}
	
	void insertFirst(double d) {
		DoubleNode newHead = new DoubleNode(d);
		newHead.setNext(head);
		head = newHead;
	}
	
	double get(int i) {
		DoubleNode cursor = head;
		if (cursor == null) {
			System.out.println("Ungültige Abfrage.");
			return -1;
		}
		
		int counter = 1;
		while (cursor.getNext() != null && counter < i) {
			cursor = cursor.getNext();
			counter ++;
		}
		return cursor.getWert();
	}
	
	void addToString() {
		DoubleNode cursor = head;
		System.out.println();
		if (cursor == null) {
			System.out.println("Ungültige Abfrage.");
		}
		do {
			System.out.print(cursor.getWert() + "; ");
			cursor = cursor.getNext();
		} while (cursor != null);
		
	}
	
	void remove(int i) {
		DoubleNode cursor = head;
		if (cursor == null) {
			System.out.println("Ungültige Abfrage.");
		}
		
		if (i == 1) {
			//für das Löschen vom ersten Element!!
			this.head = cursor.getNext();
			return;
		}
		
		int counter = 1;
		while ((cursor.getNext() != null) && (counter < i-1) && (cursor.getNext().getNext() != null)) {
			cursor = cursor.getNext();
			counter ++;
		}
		
		if (cursor.getNext().getNext() != null) {
			//für das Löschen von Objekten in der Mitte!!
			cursor.setNext(cursor.getNext().getNext());
		}
		else {
			//für das Löschen des letzten Elements!!
			cursor.setNext(null);
		}
		
	}
}
