package oose_7_1;

public class DoubleNode {
	private double wert;
	private DoubleNode next;
	
	DoubleNode() {
	}
	
	DoubleNode(double d) {
		this.wert = d;
	}
	
	double getWert() {
		return this.wert;
	}
	
	DoubleNode getNext() {
		return this.next;
	}
	
	void setWert (double d) {
		this.wert = d;
	}
	
	void setNext(DoubleNode n) {
		this.next = n;
	}
}
