package oose_7_1;

public class TestClass {

	public static void main(String[] args) {
		DoubleList list = new DoubleList();
		
		list.add(4.2);
		list.add(2.15);
		list.add(6.2155);
		list.insertFirst(42.15);
		list.insertFirst(52.15523);
		list.addToString();
		list.remove(3);
		list.addToString();
		list.remove(1);
		list.addToString();
		list.remove(3);
		list.addToString();
		System.out.println("\n" + list.get(1));
	}

}
