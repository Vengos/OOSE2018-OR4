i = 3
nichtprim = False
while i < 100:
    nichtprim = False
    k = 2
    while nichtprim == False and k < i:
        if ((i % k) == 0):
            nichtprim = True
        k+=1
    if (nichtprim == False):
        print(i)
    i+=1
        