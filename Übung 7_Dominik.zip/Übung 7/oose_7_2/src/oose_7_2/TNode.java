package oose_7_2;

public class TNode {
	private int data;
	private TNode leftChild;
	private TNode rightChild;
	
	TNode(int d, TNode lC, TNode rC) {
		this.data = d;
		this.leftChild = lC;
		this.rightChild = rC;
	}
	
	public int getData() {
		return this.data;
	}
	
	public TNode getLeftChild() {
		return this.leftChild;
	}
	
	public TNode getRightChild() {
		return this.rightChild;
	}
}
