package oose_7_2;

public class MainCl {

	public static void main(String[] args) {
		TNode n4 = new TNode(4, null, null);
		TNode n13 = new TNode(13, null, null);
		TNode n3 = new TNode(3, null, n4);
		TNode n7 = new TNode(7, null, null);
		TNode n15 = new TNode(15, n13, null);
		TNode n5 = new TNode(5, n3, n7);
		TNode n12 = new TNode(12, null, n15);
		TNode n10 = new TNode(10, n5, n12);
		Baum baum = new Baum(n10);
		
		baum.traversePreorder(baum.getRoot());
		baum.traversePostorder(baum.getRoot());
		baum.traverseInorder(baum.getRoot());
		baum.traverseLevelorder(baum.getRoot());
	}

}
