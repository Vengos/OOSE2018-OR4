package oose_7_2;
import java.util.LinkedList;

public class Baum {
	private TNode root;
	
	Baum(TNode r) {
		this.root = r;
	}
	
	public TNode getRoot() {
		return this.root;
	}
	
	public void traversePreorder (TNode Root) {
		if (Root != null) {
			if(Root == this.root) {
				System.out.println("\nPreorder: ");
			}
			System.out.print(Root.getData() + ", ");
			traversePreorder(Root.getLeftChild());
			traversePreorder(Root.getRightChild());
		}
	}
	
	public void traversePostorder (TNode Root) {
		if (Root != null) {
			if(Root == this.root) {
				System.out.println("\nPostorder: ");
			}
			traversePreorder(Root.getLeftChild());
			traversePreorder(Root.getRightChild());
			System.out.print(Root.getData() + ", ");
		}
	}
	
	public void traverseInorder (TNode Root) {
		if (Root != null) {
			if(Root == this.root) {
				System.out.println("\nInorder: ");
			}
			traversePreorder(Root.getLeftChild());
			System.out.print(Root.getData() + ", ");
			traversePreorder(Root.getRightChild());
		}
	}
	
	public void traverseLevelorder(TNode Root) {
		/* diese Implementierung löst das Problem iterativ, nicht rekursiv.
		 * Dies erscheint mir hier sinnvoller (lauf so lange über die Knoten bis es keine mehr gibt)
		 * Stimmt es, dass eine rekursive Implementierung hier umständlicher wäre,
		 * weil man beispielsweise darauf achten müsste, nicht permanent eine neue Liste zu 
		 * erzeugen etc.?
		 * Darüber hinaus finde ich Stackoperationen iterativ sowieso besser ;)
		 */
		
		if (Root != null) {
			if(Root == this.root) {
				System.out.println("\nLevelorder: ");
			}
			
			LinkedList<TNode> list = new LinkedList<TNode>();
			if (Root != null) list.push(Root);
			
			while (list.size() != 0) {
				if (list.peek().getLeftChild() != null) list.add(list.peek().getLeftChild());
				if (list.peek().getRightChild() != null) list.add(list.peek().getRightChild());
				if (list.size() != 0) { 
					System.out.print(list.peek().getData() + ", ");
					list.pop();
				}
			}
		}
	}
	
}
