
class C1 {
	static int s = 1;

	void f1() {
		System.out.println("C1::f1");
	}

	void f2() {
		System.out.println("C1::f2");
	}
}
