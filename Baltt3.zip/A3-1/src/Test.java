
public class Test {
	public static void main(String[] args) {
		C1 a = new C2();
		C2 b = new C2();
		// Stelle 1
	}
}

// 1. a wird als C2 objekt behandelt. ausgabe: C2::f1
// 2. b wird als C1 objekt behandelt aber geh�rt immer noch zu C2.
// ausgabe: C2::f1
// 3. ausgabe: 1
// 4. ausgabe: C2::f1
// 5. C2 is erweiterung von C1 somit besitz auch die methoden von C1.
// ausgabe: C1::f2
// 6. ausgabe: C2::f3
// 7. ausgabe: The method f3() is undefined for the type C1.
// Methode C1 besitz keine methode von C2 somit auch nicht f3
// 8. ausgabe: C1 cannot be cast to C2
// C2 ist erweiterung von C1 und somit C1 kann nicht als C2 behndelt werden