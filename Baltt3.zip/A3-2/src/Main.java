
public class Main {

	public static void main(String[] args) {
		var fur1 = new Fur(10);
		var sh1 = new Sheep("Johny", fur1);
		var sh2 = sh1.clone();
		System.out.println(sh1.toString());
		System.out.println(sh2.toString());
		sh2.name = "Boby";
		sh2.shear();
		System.out.println(sh1.toString());
		System.out.println(sh2.toString());
		System.out.println(sh1.equals(sh2));
		System.out.println("---------------");

		var fursc = new Fur(4);
		var sh1sc = new Sheep("Angy", fursc);
		var sh2sc = sh1sc.shallowclone();
		System.out.println(sh1sc.toString());
		System.out.println(sh2sc.toString());
		sh2sc.name = "Boss";
		sh2sc.shear();
		System.out.println(sh1sc.toString());
		System.out.println(sh2sc.toString());
		System.out.println(sh1sc.equals(sh2sc));
		System.out.println("---------------");

		var furdc = new Fur(3);
		var sh1dc = new Sheep("Genry", furdc);
		var sh2dc = sh1dc.deepclone();
		System.out.println(sh1dc.toString());
		System.out.println(sh2dc.toString());
		sh2dc.name = "Big Boss";
		sh2dc.shear();
		System.out.println(sh1dc.toString());
		System.out.println(sh2dc.toString());
		System.out.println(sh1dc.equals(sh2dc));
	}

}

// d.) Interface clonable dient dazu, eine exakte Kopie von einem Objekt zu
// erstellen.
// Clonable erstellt eine Kopie ohne Referenzierung auf Speicherbereich bei
// Objekten.
