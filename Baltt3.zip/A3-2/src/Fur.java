
public class Fur {
	public int length;

	public Fur(int length) {
		this.length = length;
	}

	public Fur(Fur originalfur) {
		this.length = originalfur.length;
	}

	public String toString() {
		return "Felllaenge: " + length;
	}
}