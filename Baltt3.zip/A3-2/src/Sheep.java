
public class Sheep {
	public String name;
	public Fur fur;

	public Sheep(String name, Fur fur) {
		this.name = name;
		this.fur = fur;
	}

	public Sheep() {
	}

	public void shear() {
		fur.length = 0;
	}

	public String toString() {
		return "Name: " + name + " " + fur.toString();
	}

	public Sheep clone() {
		return this;
	}

	public Sheep shallowclone() {
		Sheep newSheep = new Sheep();
		newSheep.name = this.name;
		newSheep.fur = this.fur;
		return newSheep;
	}

	public Sheep deepclone() {
		Sheep newSheep = new Sheep();
		newSheep.name = new String(this.name);
		newSheep.fur = new Fur(this.fur);
		return newSheep;
	}

	public boolean equals(Object o) {
		if (o instanceof Sheep) {
			if ((((Sheep) o).fur == this.fur) && (((Sheep) o).name == this.name)) {
				return true;
			}
			return false;
		}
		return false;
	}
}