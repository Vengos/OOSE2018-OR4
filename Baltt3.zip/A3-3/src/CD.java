
public class CD implements Playable {

	public void song() {
		System.out.println("O Tannenbaum....");
	}

}
