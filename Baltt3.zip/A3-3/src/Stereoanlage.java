
public class Stereoanlage {

	public void play(Playable p) {
		p.song();
	}

}
