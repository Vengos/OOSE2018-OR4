
public interface Playable {

	void song();
}
