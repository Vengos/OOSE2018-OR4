
public class Kassette implements Playable {

	public void song() {
		System.out.println("Alle meine Entchen...");
	}

}
