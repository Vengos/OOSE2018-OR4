
public class Main {

	public static void main(String[] args) {
		Stereoanlage s = new Stereoanlage();
		Playable pl = new CD();
		s.play(pl);
		pl = new Kassette();
		s.play(pl);
	}

}
// Zu erst pl wird als CD implementier und sp�ter als Kassette.