package oose_8_3;

import java.util.List;

public interface Stack extends List {
	public <T> void push(T object);

	public <T> T pop();
}
