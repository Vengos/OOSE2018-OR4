package oose_8_3;

public class StringStack implements Stack {

	private int maxSize; // number of items in stack
	private String[] stackArray;
	private int top; // top of stack

	public StringStack(int arraySize) {
		maxSize = arraySize;
		stackArray = new String[maxSize];
		top = -1;
	}

	public <T> void push(T object) { // put value on top of stack
		if (top == maxSize - 1) {
			System.out.println("Stack is full");
		} else {

			top = top + 1;
			stackArray[top] = (String) object;
		}
	}

	public String pop() { // take item from top of stack
		if (top != -1)
			return stackArray[top--]; // access item, decrement top
		else {
			System.out.println("Stack is Empty");
			return null;
		}
	}

	public void display() {

		for (int i = 0; i <= top; i++) {
			System.out.print(stackArray[i] + " ");
		}
		System.out.println();
	}
}
