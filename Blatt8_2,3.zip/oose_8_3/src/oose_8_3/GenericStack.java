package oose_8_3;

public class GenericStack implements Stack {

	private int maxSize;
	private Object[] stackArray;
	private int top;

	public GenericStack(int arraySize) {
		maxSize = arraySize;
		stackArray = new Object[maxSize];
		top = -1;
	}

	public <T> void push(T object) {
		if (top == maxSize - 1) {
			System.out.println("Stack is full");
		} else {

			top = top + 1;
			stackArray[top] = object;
		}
	}

	public Object pop() {
		if (top != -1)
			return stackArray[top--];
		else {
			System.out.println("Stack is Empty");
			return null;
		}
	}

	public void display() {

		for (int i = 0; i <= top; i++) {
			System.out.print(stackArray[i] + " ");
		}
		System.out.println();
	}
}
