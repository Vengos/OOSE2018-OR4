package oose_8_3;

public class Main {

	public static void main(String[] args) {
		StringStack newListStack = new StringStack(5);
		GenericStack newGenericStack = new GenericStack(5);
		newListStack.push("Apfel");
		newListStack.display();
		newListStack.push("Orange");
		newListStack.display();
		newListStack.pop();
		newListStack.display();
		newListStack.push("Erdbeere");
		newListStack.display();
		newListStack.push("Kiwi");
		newListStack.display();
		newListStack.pop();
		newListStack.display();
		newListStack.pop();
		newListStack.display();
		newListStack.pop();
		newListStack.display();
		newListStack.pop();
		newListStack.display();

		newGenericStack.push(2);
		newGenericStack.display();
		newGenericStack.push(5);
		newGenericStack.display();
		newGenericStack.pop();
		newGenericStack.display();
		newGenericStack.pop();
		newGenericStack.display();
	}

}
