package oose_8_2;

class R {
}

class E extends R {
}

class B extends R {
}

class G extends B {
}

class U {
}

public class Foo {
	public static <T> T bar(T x, T y) {
		return x;
	}

	public static void main(String[] args) {
		Object o;
		R r = new R();
		E e = new E();
		B b = new B();
		G g = new G();
		U u = new U();
		R[] x;
		E[] y;
	}

	/*
	 * 1) ja 2) ja 3) ja 4) ja 5) nein. R ist die Oberklasse und kann nicht objekt
	 * von Unterklasse sein. 6) nein. Weil wir koennen nur R klassen in <T>
	 * speichern. 7) ja, weil o ist ein Object 8) nein, weil e != b 9) ja 10) nein,
	 * e != b 11) ja, o ist generische objekt
	 * 
	 * 
	 */
}