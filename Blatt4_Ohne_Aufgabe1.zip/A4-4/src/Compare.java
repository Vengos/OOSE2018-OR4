import java.util.Arrays;

public class Compare {

	public static Comparable find_Min(Comparable[] x) {
		var temp = x;
		Arrays.sort(temp);
		return temp[0];
	}

}
