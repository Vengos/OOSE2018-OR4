
public class Person implements Comparable<Person> {

	String name;
	String vorname;
	int Postleitzahl;
	String Strasse;
	int Hausnummer;

	public Person(String name, String vorname, int Postleitzahl, String Strasse, int Hausnummer) {
		this.name = name;
		this.vorname = vorname;
		this.Postleitzahl = Postleitzahl;
		this.Strasse = Strasse;
		this.Hausnummer = Hausnummer;
	}

	public int compareTo(Person o) {
		if (this.name.toLowerCase().compareTo(o.name.toLowerCase()) == 0) {
			if (this.vorname.toLowerCase().compareTo(o.vorname.toLowerCase()) == 0) {
				if (Integer.compare(this.Postleitzahl, o.Postleitzahl) == 0) {
					if (this.Strasse.toLowerCase().compareTo(o.Strasse.toLowerCase()) == 0) {

						return Integer.compare(this.Hausnummer, o.Hausnummer);
					}

					return this.Strasse.compareTo(o.Strasse);
				}

				return Integer.compare(this.Postleitzahl, o.Postleitzahl);
			}

			return this.vorname.compareTo(o.vorname);
		}

		return this.name.compareTo(o.name);
	}

}
