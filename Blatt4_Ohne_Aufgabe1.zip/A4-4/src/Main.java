public class Main {

	public static void main(String[] args) {
		Person[] people = new Person[4];
		Person p1 = new Person("John", "Doe", 5, "High", 50);
		Person p2 = new Person("John", "Doe", 5, "High", 30);
		Person p3 = new Person("John", "Doe", 5, "High", 10);
		Person p4 = new Person("Jane", "Doe", 5, "High", 50);

		people[0] = p1;
		people[1] = p2;
		people[2] = p3;
		people[3] = p4;

		Person result = (Person) Compare.find_Min(people);

		System.out.println(result.name + " " + result.vorname + " " + result.Hausnummer);

		Integer[] array = { 7, 5, 0, 1 };

		System.out.println((int) Compare.find_Min(array));

	}

}
