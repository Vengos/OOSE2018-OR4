
public class Main {

	public static void main(String[] args) {

		Auto auto1 = new Lastwagen();
		System.out.println(auto1.reifen); // Ausgabe 1)
		System.out.println(((Lastwagen) auto1).reifen); // Ausgabe 2)
		System.out.println(auto1.getReifen()); // Ausgabe 3)
		System.out.println(((Lastwagen) auto1).getReifen()); // Ausgabe 4

	}

}

// a.) Ausgabe1: 4
// auto1 besitz 2 deifnition von reifen. Eine ist von Klass Auto und andere von
// Klass Lastwagen.
// Bei Ausgabe1 wird nach Reifen direkt gefragt und die erste Definition von
// Variable reifen ist von Klass Auto, da wir auto1 als Auto definieren und nun
// spaeter sagen, dass dieses Objekt zur Klasse Lastwagen geh�rt
// Ausgabe2: 8
// Hier wird definiert dass die Variable reifen von klass Lastwagen ausgegeben
// soll
// Ausgabe3: 8
// Hier wird die Methode von dem Klass wie der Objekt auto1 aufgerufen.
// d.h. Lastwagen -> getReifen
// Ausgabe4: 8
// Hier wird explizit die Methode getReifen von Klasse Lastwagen aufgerefen
// Es ist redundant, da das Objekt auto1 die Klasse Lastwagen geh�rt
// b.) Da die Klasse Lastwagen keine Methode getReifen besitzt wird immer
// dieselber Methode von Klass Auto aufgerufen
// Somit gibt die Methode getReifen immer die Variable reifen von Klasse Auto
// zur�ck
// d.h. Ausgabe 3,4: 4
// c.) Wir haben auto1 als Objekt von Klasse Auto definiert und entfernen von
// Methode getReifen in Klasse Auto f�gt zu einer Fehler
// Das Objekt auto1 vor der Zuweisung versucht nicht existierende Methode
// getReifen aufrufen.
// Um diese fehler zu korregieren das Objekt auto1 soll als Lastwagen Objekt
// definiert werden.
// d.h. Lastwagen auto1 = new Lastwagen();