
public class Auto {
	int reifen = 4;

	int getReifen() {
		return this.reifen;
	}
}