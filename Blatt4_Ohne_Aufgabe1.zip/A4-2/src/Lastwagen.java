
public class Lastwagen extends Auto {
	int reifen = 8;

	int getReifen() {
		return this.reifen;
	}
}