package oose_1_2;


public class Name {

	public static void main(String[] args) {
		System.out.print("Wie ist dein Name? ");
		String name = Input.readString();
		System.out.println("Hallo " + name + "!");
		
	}

}
