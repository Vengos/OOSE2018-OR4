package oose_1_3;

public class Aufg3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		java.util.Scanner sc = new java.util.Scanner(System.in);
		System.out.println("Eingabe: ");
		int k = sc.nextInt(); // liest eine Ganzzahl (int) ein
		System.out.println(++k); // Ausgabe a)
		System.out.println(k); // Ausgabe b)
		System.out.println(k++); // Ausgabe c)
		int k2 = 5;
		double result = (double) k2 / 2; // Stelle 1
		System.out.println("5 / 2 = " + result); // Ausgabe d)
		boolean b = false;
		if(b = false) {
		System.out.println("b ist falsch."); // Ausgabe e)
		} else {
		System.out.println("b ist wahr."); // Ausgabe f)
		}
	}
	/*a) inkrementiert k vor der Ausgabe
	b) gibt k aus so wie es ist
	c) gibt k aus und inkrementiert es hinterher
	
	Stelle 1 müsste lauten: double result = (double) k2 / 2;
	
	Fehler: in if(b= false) wird b der Wert false zugewiesen. Korrektur durch b==false.
	b = false evaluiert im if-Block zu false, weswegen er nicht ausgeführt und stattdessen der else-Block getriggert wird.
	*/
}
