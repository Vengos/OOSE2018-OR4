package oose_1_4;

public class Operatoren {
	public static void main(String [] args){
		int a=15;
		int b=34;
		int c=1;
		System.out.println("1: "+ (a==b));				//"false", weil a!=b.
		System.out.println("2: "+ (a==b-19));			//"true", weil b-19=15 == a.
		System.out.println("3: "+ (a^b));				//"45", weil "^" der bitweise XOR-Vergleichsoperator ist. 001111 (15) ^ 100010 (34) = 101101 (45).
		System.out.println("4: "+ (a++^b));				//"45", weil der Vergleichsoperator stärker bindet als das Inkrement
		System.out.println("5: "+ (7<<++c));			//"28", weil c=1 inkrementiert wird zu c=2, anschließend die 111 (7) um 2 Bit nach links geschoben wird: 11100 (28).
		System.out.println("6: "+ (a=b=c=0x10));		//"16", weil die Hexzahl 0x10 den Dezimalwert 16 hat.
		System.out.println("7: "+ (1e1));				//"10", weil das die wissenschaftliche Schreibweise für "1 * (10^1)" ist, Wert 10.
		}
		}

