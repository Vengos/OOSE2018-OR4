package oose_6_2;
import java.io.File;

public class Maincl62 {

	public static void main(String[] args) {
		File test = new File("E:/testtext.txt");
		
			Thread beobachter = new Thread(new DateiBeobachter(test));
			beobachter.start();
				
	}

}
