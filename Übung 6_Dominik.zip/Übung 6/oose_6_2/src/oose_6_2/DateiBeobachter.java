package oose_6_2;
import java.io.File;


public class DateiBeobachter implements Runnable {
	
	File testFile;
	
	DateiBeobachter(String kette) {
		testFile = new File(kette);
	}
	
	DateiBeobachter(File datei) {
		testFile = datei;
	}
	
	public void run() {
		long aenderung1 = testFile.lastModified();
		long aenderung2 = testFile.lastModified();
		
		while (true) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			
			if(aenderung1 == aenderung2) {
				System.out.println(testFile.getAbsolutePath());
				aenderung1 = aenderung2;
				aenderung2 = testFile.lastModified();
			} else {
				System.out.println("File has been modified!");
				return;
			}
			
			
		}
		
	}
	
	

}
