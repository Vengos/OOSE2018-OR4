package oose_6_3;
import java.io.IOException;

public class Maincl {

	public static void main(String[] args) {
		Hamburger c = new Hamburger();
		c.eat();
	}

}


/*
 * a: problemlos möglich
 * b: "Exception Exception is not compatible with throws clause in Fastfood.eat()" bei Hamurger.eat()
 * c: "Unhandled Exception type IOException" bei c.eat()
 * d: wie c
 * e: problemlos möglich
 */
