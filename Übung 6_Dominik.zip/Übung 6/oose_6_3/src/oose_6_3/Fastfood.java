package oose_6_3;
import java.io.IOException;

public class Fastfood {
	void eat () throws IOException {}
}
