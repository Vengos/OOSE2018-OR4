package oose_6_3;
import java.io.*;

public class Hamburger extends Fastfood{
	void eat() throws RuntimeException {}
}
