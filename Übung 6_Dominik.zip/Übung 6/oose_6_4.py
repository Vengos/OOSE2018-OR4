zahl = int(input("Welche Collatz Folge?  "))
print (zahl)
while (zahl != 1):
    if(zahl % 2 == 0):
        zahl = (zahl/2)
        print (zahl)
    else:
        zahl = (3*zahl + 1)
        print (zahl)
    