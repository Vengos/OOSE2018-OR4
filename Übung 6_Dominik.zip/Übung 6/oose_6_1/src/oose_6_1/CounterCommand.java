package oose_6_1;

public class CounterCommand implements Runnable {

	static int sleeptimer() {
		int timer = new java.util.Random().nextInt(1000);
		return timer;
	}
	
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println(i);
			
			try {
				Thread.sleep(sleeptimer());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
