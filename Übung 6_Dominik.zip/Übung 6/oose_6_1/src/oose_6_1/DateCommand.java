package oose_6_1;

import java.util.Date;

public class DateCommand implements Runnable {

	static int sleeptimer() {
		int timer = new java.util.Random().nextInt(1000);
		return timer;
	}
	
	static Date getDate() {
		Date currentDate = new java.util.Date();
		return currentDate;
	}
	
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println(getDate());
			
			try {
				Thread.sleep(sleeptimer());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
