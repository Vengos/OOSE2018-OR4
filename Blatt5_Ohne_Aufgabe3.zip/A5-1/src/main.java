
public class main {

	public static void main(String[] args) {
		Praktikant test = new Praktikant("John", "Doe", 20);
		test.Raise_Sallary(5);
		System.out.println(test.getGehalt());

	}

}
