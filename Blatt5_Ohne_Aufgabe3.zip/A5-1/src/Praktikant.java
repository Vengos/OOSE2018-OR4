
public class Praktikant extends Angestellter {

	public Praktikant(String vorname, String nachname, int alter) {
		super(vorname, nachname, alter, 400);
		// TODO Auto-generated constructor stub
	}

	protected void Raise_Sallary(int number) {
		System.out.println("Praktikanten arbeiten nur f�r Essen");
	}

}
