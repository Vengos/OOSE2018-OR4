import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {

		ArrayList<Koerper> test = new ArrayList<>();
		double[] p1 = { 2, 3, 4 };
		double[] p2 = { 7, 5, 1 };
		double[] p3 = { 9, 8, 3 };
		double[] p4 = { 4, 5, 5 };
		Kugel kg1 = new Kugel(p1, 2);
		Kugel kg2 = new Kugel(p2, 5);
		Quader qu1 = new Quader(p3, 2, 1, 5);
		Quader qu2 = new Quader(p4, 7, 5, 2);

		test.add(kg1);
		test.add(kg2);
		test.add(qu1);
		test.add(qu2);

		for (Koerper koerper : test) {
			koerper.printInfo();
		}

	}

}
