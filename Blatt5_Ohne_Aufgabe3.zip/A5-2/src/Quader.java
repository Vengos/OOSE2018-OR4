
public class Quader implements Koerper {

	double[] p = new double[3];
	double volume = 0;
	double height;
	double width;
	double depth;
	String art = "Quader";

	public Quader(double[] p, double height, double width, double depth) {
		this.p = p;
		this.height = height;
		this.width = width;
		this.depth = depth;
		calcVolume();
	}

	public void move(double[] m) {
		for (int i = 0; i < 3; i++) {
			this.p[i] = this.p[i] + m[i];
		}
	}

	public void scale(double s) {
		this.height = this.height * s;
		this.width = this.width * s;
		this.depth = this.depth * s;
	}

	public void calcVolume() {
		this.volume = this.height * this.width * this.depth;
	}

	public void printInfo() {
		System.out.println("Art:" + art);
		System.out.println("Volumen:" + volume);
		System.out.println("Position h�he:" + p[0]);
		System.out.println("Position breite:" + p[1]);
		System.out.println("Position tiefe:" + p[2]);
		System.out.println("");
	}

}
