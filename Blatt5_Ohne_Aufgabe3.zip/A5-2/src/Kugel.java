
public class Kugel implements Koerper {

	double[] p = new double[3];
	double volume;
	double radius;
	String art = "Kugel";

	public Kugel(double[] p, double radius) {
		this.p = p;
		this.radius = radius;
		calcVolume();
	}

	public void move(double[] m) {
		for (int i = 0; i < 3; i++) {
			this.p[i] = this.p[i] + m[i];
		}
	}

	public void scale(double s) {
		this.radius = this.radius * s;
	}

	public void calcVolume() {
		this.volume = (4 / 3) * Math.PI * Math.pow(radius, 3);
	}

	public void printInfo() {
		System.out.println("Art:" + art);
		System.out.println("Volumen:" + volume);
		System.out.println("Position h�he:" + p[0]);
		System.out.println("Position breite:" + p[1]);
		System.out.println("Position tiefe:" + p[2]);
		System.out.println("");
	}

}
