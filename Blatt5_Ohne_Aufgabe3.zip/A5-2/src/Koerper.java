
public interface Koerper {

	double[] p = new double[3];
	double volume = 0;
	String art = "Koerper";

	void move(double[] m);

	void scale(double s);

	void calcVolume();

	void printInfo();

}
