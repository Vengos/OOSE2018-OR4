
public class TestTrace {
	public static void main(String[] args) {
		CallEg eg = new CallEg(); // use default constructor
		try {
			eg.methodA();
		} catch (ArithmeticException oops) {
			oops.printStackTrace();
		}
	}
}

// a.) java.lang.ArithmeticException: / by zero
// at CallEg.methodA(CallEg.java:5)
// at TestTrace.main(TestTrace.java:6)

// b.) java.lang.ArithmeticException: / by zero
// at CallEg.methodC(CallEg.java:13)
// at CallEg.methodB(CallEg.java:8)
// at CallEg.methodA(CallEg.java:4)
// at TestTrace.main(TestTrace.java:6)

// c.) java.lang.ArithmeticException: / by zero
// at CallEg.methodC(CallEg.java:24)
// at CallEg.methodB(CallEg.java:14)
// at CallEg.methodA(CallEg.java:5)
// at TestTrace.main(TestTrace.java:6)
// java.lang.ArithmeticException: / by zero
// at CallEg.methodC(CallEg.java:24)
// at CallEg.methodB(CallEg.java:14)
// at CallEg.methodA(CallEg.java:5)
// at TestTrace.main(TestTrace.java:6)
// java.lang.ArithmeticException: / by zero
// at CallEg.methodC(CallEg.java:24)
// at CallEg.methodB(CallEg.java:14)
// at CallEg.methodA(CallEg.java:5)
// at TestTrace.main(TestTrace.java:6)
// java.lang.ArithmeticException: / by zero
// at CallEg.methodC(CallEg.java:24)
// at CallEg.methodB(CallEg.java:14)
// at CallEg.methodA(CallEg.java:5)
// at TestTrace.main(TestTrace.java:6)