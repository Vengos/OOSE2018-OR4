package oose_8_1;

public class Hund extends Tier {

}
