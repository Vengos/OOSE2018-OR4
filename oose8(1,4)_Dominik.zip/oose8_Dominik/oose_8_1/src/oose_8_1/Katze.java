package oose_8_1;

public class Katze extends Tier {

}
