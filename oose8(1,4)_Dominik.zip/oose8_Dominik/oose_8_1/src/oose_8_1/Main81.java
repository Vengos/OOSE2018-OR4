package oose_8_1;

public class Main81 {

	public static void main(String[] args) {
		TierKaefig<Tier> kaefig= new TierKaefig<Katze>();
			//nicht kompilierbar (Type mismatch)
		
		TierKaefig<Hund> kaefig2= new TierKaefig<Tier>();
			//nicht kompilierbar (Type mismatch)
		
		TierKaefig<?> kaefig3= new TierKaefig<Katze>();
		kaefig3.setInsasse(new Katze());
			//nicht kompilierbar (setInsasse(Katze) ist nicht kompatibel mit Tierkäfig<?>. Mit Tierkäfig<Katze> alles kein problem
		
		
		TierKaefig kaefig4 = new TierKaefig();
		kaefig4.setInsasse(new Hund());
			//nur mit Warnung kompilierbar, dass die Referenz auf den generischen Typ TierKaefig<E> parametrisiert sein sollte
	}

}
