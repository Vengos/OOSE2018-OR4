package oose_8_4;

public class MainCl {

	public static void main(String[] args) {
		Primfaktorzerlegung n = new Primfaktorzerlegung(false, "normal", 2, 20000);
		n.operate();
		Thread g = new T_Primfaktorzerlegung(false, "gerade", 2, 20000);
		Thread u = new T_Primfaktorzerlegung(false, "ungerade", 3, 20000);
		g.start();
		u.start();
		//------------------
		Primfaktorzerlegung n2 = new Primfaktorzerlegung(true, "normal2", 1000000, 1000010);
		n2.operate();
		Thread g2 = new T_Primfaktorzerlegung(true, "gerade2", 1000000, 1000010);
		Thread u2 = new T_Primfaktorzerlegung(true, "ungerade2", 1000001, 1000010);
		g2.start();
		u2.start();
		
		
		
	}

}
