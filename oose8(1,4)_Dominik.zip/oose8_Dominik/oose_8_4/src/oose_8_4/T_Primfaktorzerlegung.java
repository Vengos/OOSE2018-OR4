package oose_8_4;

public class T_Primfaktorzerlegung extends Thread {
	
	//dieselben Methoden, Unterschied: zerlege() iteriert in Zweierschritten. So kann ein Thread gerade, der andere ungerade berechnen.
	//zerlege () hat keine Ausgabe. (Sonst kommt bei paralleler Ausführung alles durcheinander!)
	int a;
	int b;
	String name;
	boolean toPrint;
	
	T_Primfaktorzerlegung (boolean tP, String n, int l, int r) {
		this.a = l;
		this.b = r;
		this.name = n;
		this.toPrint = tP;
	}
	
	public void run () {
		System.out.println("Process " + name + " initiated. Now calculating.");
		long time1 = System.currentTimeMillis();
		long time2;
		zerlege();
		time2 = System.currentTimeMillis();
		time2 -= time1;
		System.out.println("Process " + name + " done. Took " + time2 + " ms.");
		
	}
	
	int findNextPrime(int v)  {	//returns the next prime number after the parameter int v. Even if v is not prime itself.
		int nextPrime = v+1;
		int i = 2;
		boolean isPrime = false;
		while (isPrime == false) {
			if (nextPrime % i == 0) {
				nextPrime++;
				i = 2;
			} else {
				i++;
			}
			if (i >= nextPrime/2) {
				isPrime = true;
			}
		}
		return nextPrime;
	}

	void zerlege () {
		int c = a; // "cursor"
		int f = c; // "faktor"
		int p; //zu prüfender Primfaktor (p ist prim)
		boolean cIsDone;
		while (c <= b) {
			f = c;
			if (toPrint == true) System.out.print(c + ": ");
			cIsDone = false;
			p = 2;
			while (cIsDone == false) {
				while (f % p == 0 && f > 1) { //eine zahl kann öfter als ein Mal durch einen Faktor teilbar sein...
					if (toPrint == true) System.out.print(p + " * ");
					f /= p;
				}
				p = findNextPrime(p);
				if (f==1 || p >= (c/2)+1) {
					cIsDone = true;
				}
			}
			c+=2;
			if (toPrint == true) System.out.print("\n");
		}
	}
}
