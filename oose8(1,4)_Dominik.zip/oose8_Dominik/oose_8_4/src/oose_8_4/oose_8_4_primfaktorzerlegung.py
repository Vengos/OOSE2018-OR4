def findnextprime(v):
    nextPrime = v+1
    i = 2
    isPrime = False
    while (isPrime == False):
        if (nextPrime % i == 0):
            nextPrime += 1
            i = 2
        else:
            i += 1
        if (i >= (nextPrime / 2)):
            isPrime = True
    return nextPrime

#"zerlege";

a = 2
b = 100

c = a
f = c


while (c <= b):
    f = c
    print (c)
    print (": ")
    cIsDone = False
    p = 2
    while (cIsDone == False):
        while (f % p == 0 and f > 1):
            print (p)
            print ( " * ")
            f /= p
        p = findnextprime (p)
        if (f == 1 or p >= (c/2)+1):
            cIsDone = True
    c += 1
    print ("\n")