package oose_5_3;

public class SelectionSort {
	static double[] unsortiert = new double[100];
	static double[] sortiert = new double[100];
	static boolean[] benutzt = new boolean[100];
	
	static int findIndexMax (double[] array) {
		int maxIndex = 0;
		double maxElement = array[0];
		for (int i = 0; i < 100; i++) {
			if (array[i] > maxElement) {
				maxElement = array[i];
				maxIndex = i;
			}
		}
		return maxIndex;
	}
	
	static int findIndexMin (double[] array, int maxIndex) {
		int minIndex = 0;
		double minElement = array[maxIndex];//das kleinste Element muss mit dem größten Initialisiert werden, weil nur die Elemente des Arrays sortiert werden, die kleiner sind als dieses.
		
		for (int i = 0; i < 100; i++) {
			if (benutzt[i] == false && array[i] < minElement) {
				minElement = array[i];
				minIndex = i;
				
			}
			
		}
		benutzt[minIndex] = true;
		return minIndex;
	}
	
	static boolean appendToArray (double element, int stelle) {
		boolean done = false;
		sortiert[stelle] = element;
		
		if (sortiert[stelle] == element) {
			done = true;
		}
		
		return done;
	}
	
	static void printArray(double[] a1, double[] a2, int length) {
		for (int i = 0; i < length; i++) {
			System.out.println(a1[i] + "\t" + a2[i]);
		}
	}

	public static void main(String[] args) {
		int fertig = 0;
		java.util.Random rnd = new java.util.Random();
		for (int i = 0; i < 100; i++) {
			unsortiert[i] = rnd.nextDouble();
			benutzt[i] = false;
		}
		
		int mindex;
		int maxdex = findIndexMax(unsortiert);
		
		while (fertig < 100) {
			mindex = findIndexMin(unsortiert, maxdex);
			boolean erfolg = false;
			do{erfolg = appendToArray(unsortiert[mindex], fertig);}while (!erfolg);
			fertig++;
		}
		
		printArray(unsortiert, sortiert, 100);
	}

}
