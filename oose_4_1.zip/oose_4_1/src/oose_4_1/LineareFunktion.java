package oose_4_1;
import java.util.concurrent.ThreadLocalRandom;

public class LineareFunktion implements Evaluierbar {
	//die lineare Funktion ist zufällig!
	float m = ThreadLocalRandom.current().nextFloat() + ThreadLocalRandom.current().nextInt(0, 1000) - ThreadLocalRandom.current().nextInt(0, 1000);
	float b = ThreadLocalRandom.current().nextFloat() + ThreadLocalRandom.current().nextInt(0, 1000) - ThreadLocalRandom.current().nextInt(0, 1000);
	
	public String getName() {
		return (m + " * x + " + b);
	}

	public int evaluate(int x) {
		int y;
		float res = (m*x)+b;
		y = Math.round(res);
		return y;
	}

}
