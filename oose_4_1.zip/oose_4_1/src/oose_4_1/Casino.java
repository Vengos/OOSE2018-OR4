package oose_4_1;
import java.util.Scanner;

public class Casino {
	
	
	public static void menu() {
		System.out.println("Sie befinden sich im Hauptmenü. Herzlichen Glückwunsch! Was möchten Sie gern spielen?");
		System.out.println("0. Ich habe genug!");
		System.out.println("1. HochTief");
		System.out.println("2. Funktionswerteraten");
		return;
	}

	public static void main(String[] args) {
		int auswahl;
		Scanner sc = new Scanner(System.in);
		Spielemanager manager = new Spielemanager(50);
		System.out.println("Willkommen im Casino!");
		
		do {
			menu();
			Spiel neuesSpiel = null;
			auswahl = sc.nextInt();
			sc.nextLine();
			switch (auswahl) {
				case 0: {
					System.out.println("Ok. Vielen Dank für Ihren Besuch! Sie verlassen unser Casino heute mit " + manager.getKapital());
					return;
					}
				case 1: {
					neuesSpiel = new HochTief();
					break;
					}
				case 2: {
					neuesSpiel = new Funktionswerteraten();
					break;
					}
				default: {
					System.out.println("Ein solches Spiel existiert nicht. Das Programm wird nun heruntergefahren, um unerwünschtem Verhalten hervorzubeugen.");
					return;
					}
			}
			
			manager.starteSpiel(neuesSpiel);
		} while (auswahl != 0);
		sc.close();
		return;
	}

}
