package oose_4_1;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Funktionswerteraten extends Spiel {
	Funktionswerteraten() {
		super("Funktionswerteraten");
	}
	
	int spiele() {
		int f = (ThreadLocalRandom.current().nextInt()) % 2; //Wert 0 oder 1, wählt die Funktion aus.
		int x = ThreadLocalRandom.current().nextInt(1, 51); //Wert 1 bis 50, wählt den X wert aus.
		
		System.out.println("Willkommen beim Spiel Funktionswerteraten. Für Sie wurde die ");
		if (f == 0) System.out.print("Lineare Funktion ");
		else System.out.print("e-Funktion ");
		System.out.print("ausgewählt. ");
		
		int loesung;
		
		if (f == 0) {
			LineareFunktion lin = new LineareFunktion();
			loesung = lin.evaluate(x);
			System.out.println("Sie lautet " + lin.getName());
		}
		else {
			eFunktion ef = new eFunktion();
			loesung = ef.evaluate(x); //e^x überschreitet den wertebereich von integer schnell für große x!
			System.out.println("Sie lautet " + ef.getName() + ".");
		}
		
		System.out.println("Welchen Wert hat die Funktion ungefähr an der Stelle x = " + x + "?");
		int eingabe;
		
		Scanner scanner = new Scanner(System.in);
		eingabe = scanner.nextInt();
		//scanner.close();
		
		
		System.out.println("Die richtige Antwort ist " + loesung);
		
		int diff = Math.abs(loesung - eingabe);
		
		if (diff <= 5) {
			System.out.println("Damit haben Sie richtig geraten! Herzlichen Glückwunsch!");
			return (Spiel.getEinsatz() + x);
		}
		System.out.println("Damit haben Sie verloren. Ha ha.");
		return 0;

	}
}
