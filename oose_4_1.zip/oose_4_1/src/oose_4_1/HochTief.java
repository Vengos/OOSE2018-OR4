package oose_4_1;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class HochTief extends Spiel {
	HochTief() {
		super("HochTief");
	}
	
	int loesung = ThreadLocalRandom.current().nextInt(0, 101);
	int eingabe;
	
	
	int spiele() {
		int runde = 0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Willkommen beim Spiel HochTief. Bitte geben Sie eine Zahl ein.");
		eingabe = scanner.nextInt();
		//scanner.reset();
		
		while (runde <= 5) {
			if (eingabe == loesung) {
				System.out.println("Das ist korrekt! Sie haben gewonnen!");
				return 2*(Spiel.getEinsatz());
			}
			else if (eingabe < loesung) {
				System.out.println("Das war zu niedrig.");
			}
			else if (eingabe > loesung) {
				System.out.println("Das war zu hoch.");
			}
			runde++;
			if (runde < 5) {
				System.out.print(" Versuchen Sie es erneut. Ihnen bleiben noch " + (5-runde) + " Versuch(e)\n");
				eingabe = scanner.nextInt();
				scanner.reset();
				
			}
			else if (runde == 5) {
				System.out.println("Sie haben verloren. Ha ha. Die richtige Antwort wäre " + loesung + " gewesen.\n\n-----------------------\n");
				return 0;
			}
		}
		//scanner.close();
		return 0;
		
	}
	
	
	
}
