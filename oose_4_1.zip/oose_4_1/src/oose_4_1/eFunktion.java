package oose_4_1;

public class eFunktion implements Evaluierbar {
	
	
	public String getName() {
		return "e^x";
	}
	
	public int evaluate (int x) {
		/* Der Cast auf den Typ float ist wichtig, weil
		 * evaluate() den Rückgabetyp int hat.
		 * damit muss y vom Typ int sein.
		 * pow gibt allerdings double zurück.
		 * Ist der Parameter von round ein double, ist dessen
		 * Rückgabe long.
		 * Alternativ könnte auch erst hier auf int gecastet werden.
		 */
		
		
		int y;
		float res = (float) Math.pow(Math.E, x); 
		y = Math.round(res);
		return y; 
	}
}
