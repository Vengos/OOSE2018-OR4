package oose_4_1;

public interface Evaluierbar {
	public String getName();
	public int evaluate(int x);
}
