package oose_4_1;

public abstract class Spiel {
	private String Name;
	private static int Einsatz;
	
	Spiel(String spielname) {
		this.Name = spielname;
	}
	
	protected void setEinsatz(int einsatz) {
		this.Einsatz = einsatz;
	}
	
	protected static int getEinsatz() {
		return Einsatz;
	}
	
	abstract int spiele();
}
