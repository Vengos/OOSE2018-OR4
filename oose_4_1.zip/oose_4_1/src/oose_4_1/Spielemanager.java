package oose_4_1;
import java.util.Scanner;

public class Spielemanager {
	int kapital;
	
	Spielemanager(int neueskapital) {
		this.kapital = neueskapital;
	}
	
	int getKapital () {
		return this.kapital;
	}
	
	
	public void starteSpiel(Spiel sp) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Wie viel möchten Sie setzen? Sie haben " + kapital);
		int einsatz;
		do {
			einsatz = sc.nextInt();
			sc.nextLine();
			
			if (einsatz > kapital) {
				System.out.println("Sie haben nicht so viel. Setzen Sie weniger.");
			}
		} while (einsatz > kapital);

		
		
		
		sp.setEinsatz(einsatz);
		kapital -= einsatz;
		
		int gewinn;
		gewinn = sp.spiele();
		kapital += gewinn;
	
		return;
		
	}
}
