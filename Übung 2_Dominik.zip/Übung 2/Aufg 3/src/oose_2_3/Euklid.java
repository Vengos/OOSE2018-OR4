package oose_2_3;

public class Euklid {
	
	public static int ggT(int a, int b) {
		int res;
		
		if (a == 0) {
			res = b;
		}
		
		else {
			while (b != 0) {
				if (a > b) {
					a = a - b; //a -= b;
				}	
				else {
					b = b - a; //b -= a;
				}
			}
			res = a;
		}
		
		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print(ggT(9, 11));
	}

}
