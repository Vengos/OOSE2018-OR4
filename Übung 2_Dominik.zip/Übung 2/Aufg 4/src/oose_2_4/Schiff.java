package oose_2_4;

public class Schiff {
	
	private String name;
	private String kennzeichen;
	private double länge;
	
	public Schiff(String newname, double newlänge) {
		name = newname;
		länge = newlänge;
	}
	
	public void setKennzeichen (String newkennzeichen) {
		kennzeichen = newkennzeichen;
	}
	
	public void empfangeNachricht (String msg) {
		System.out.println("\"" + msg + "\", " + name + "/" + kennzeichen);
	}

}
