package oose_2_4;

public class Schiffahrtsamt {
	Schiff[] SchiffsArray = new Schiff[50];
	byte stelle = 0;
	
	
	//Annahme: Schiffe sind unsinkbar und werden nie abgemeldet. Ansonsten wäre evtl. eine etwas dynamischere Verwaltung des Arrays nötig.
	public void registriereSchiff(Schiff neuesSchiff) {
		SchiffsArray[stelle] = neuesSchiff;
		System.out.println("Ein neues Schiff wurde registriert!");
		stelle++;
	}
	
	public void meldung (String nachricht, int dringlichkeit) {
		if (dringlichkeit == 1) {	
			for (int i = 0; i < stelle; i++) {
				SchiffsArray[i].empfangeNachricht(nachricht);
			}
		}
	}
	
	public static String getKennzeichen() {
		java.util.Random rnd = new java.util.Random();
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < 6; i++) {
		sb.append((char)((rnd.nextInt(25)+65)));
		}
		return sb.toString();
		}
}
