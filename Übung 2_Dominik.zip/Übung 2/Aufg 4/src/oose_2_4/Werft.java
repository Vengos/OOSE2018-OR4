package oose_2_4;

public class Werft {
	
	public static void produziereSchiff (String name, double länge, Schiffahrtsamt amt) {
		Schiff sh = new Schiff(name, länge);
		amt.registriereSchiff(sh);
		String neuesKennzeichen = amt.getKennzeichen();
		sh.setKennzeichen(neuesKennzeichen);
	}
}
