package oose_2_1;

public class Lottoproblem {
	
	static long fak(long n) {
		long res = 1;
		
		if (n<1) {
			return res;
		}
		
		if (n==1) {
			return res;
		}
		else {
		res = n * fak(n-1);
		}
		return res;
	}
	
	static long binomk(long n, long k) {
		long res = 0;
		
		if (n < 0 || k < 0) {
			System.out.println("Error Code: 1");
			return res;
		}
		
		if (n < k) return 0;
		else {
			res = ((fak(n)) / ((fak(k))*(fak(n-k))));
		}
		
		return res;
	}
	
	static long lotto(long n, long k) {
		long res = 1;
		
			res = binomk(n,k) * fak(k);
		
		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(lotto(49,6));
	}

}
