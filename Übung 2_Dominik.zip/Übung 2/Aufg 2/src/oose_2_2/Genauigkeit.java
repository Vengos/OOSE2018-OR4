package oose_2_2;

public class Genauigkeit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double zahl1=6.4, zahl2=6.4f;
		System.out.print("6.4 = 6.4f? : ");
		System.out.println(zahl1==zahl2); //false
		zahl1 = 6.5;
		zahl2 = 6.5f;
		System.out.print("6.5 = 6.5f? : ");
		System.out.print(zahl1==zahl2); //true
	}

}

/*Erklärung:
*	Gleitkommaarithmetik ist hinsichtlich im Dezimalsystem "einfachen" Mantissen problematisch.
*	Im Binärsystem ist eine solche Darstellung manchmal nur näherungsweise möglich, da 0.4 beispielsweise 
*	eine periodische Zahl ist.
*	Die Variable vom Typ double mit 6.4 ist hier sehr viel genauer als float mit 6.4f - so kommt es, dass 
*	es als verschieden interpretiert wird (mehr von 0 verschiedene Bits weit hinter dem Komma). 
*	Anders bei 6.5 und 6.5f: Die Mantisse ist hier schlicht 0.5, also 1/2. Sowohl in single- als auch double
*	precision ergibt sich eine Mantisse von "1000000000000000000" mit mehr Nullen beim double. 
*	Da diese den Wert nicht weiter verändern, evaluiert dieser Vergleich korrekterweise zu true. 
*/